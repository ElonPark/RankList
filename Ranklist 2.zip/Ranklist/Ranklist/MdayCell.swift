//
//  MdayCell.swift
//  Ranklist
//
//  Created by Nebula_MAC on 2016. 1. 11..
//  Copyright © 2016년 Nebula_MAC. All rights reserved.
//

import UIKit

class MdayCell: UITableViewCell {
    
    @IBOutlet var rank: UILabel!
    @IBOutlet var movieNm: UILabel!
    @IBOutlet var openDt: UILabel!
    @IBOutlet var rankInten: UILabel!
    @IBOutlet var rankOldAndNew: UILabel!
}
