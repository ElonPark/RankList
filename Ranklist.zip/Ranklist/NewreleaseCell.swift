//
//  NewreleaseCell.swift
//  Ranklist
//
//  Created by Nebula_MAC on 2016. 1. 10..
//  Copyright © 2016년 Nebula_MAC. All rights reserved.
//

import UIKit

class NewreleaseCell: UITableViewCell {
    
    @IBOutlet var albumName: UILabel!
    @IBOutlet var artistName: UILabel!
    @IBOutlet var countScore: UILabel!
    @IBOutlet var issueDate: UILabel!
}
