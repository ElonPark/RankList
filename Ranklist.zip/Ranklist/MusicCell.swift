//
//  MusicCell.swift
//  Ranklist
//
//  Created by Nebula_MAC on 2016. 1. 9..
//  Copyright © 2016년 Nebula_MAC. All rights reserved.
//

import UIKit

class MusicCell: UITableViewCell {
    
    @IBOutlet var cRank: UILabel!
    
    @IBOutlet var songName: UILabel!
    
    @IBOutlet var artist: UILabel!

    @IBOutlet var albumName: UILabel!
    
    @IBOutlet var pastRank: UILabel!
}
