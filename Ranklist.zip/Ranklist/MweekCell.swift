//
//  MweekCell.swift
//  Ranklist
//
//  Created by Nebula_MAC on 2016. 1. 11..
//  Copyright © 2016년 Nebula_MAC. All rights reserved.
//

import UIKit

class MweekCell: UITableViewCell {
  
    @IBOutlet var rank: UILabel!
    @IBOutlet var movieNm: UILabel!
    @IBOutlet var openDt: UILabel!
    @IBOutlet var audiAcc: UILabel!
    @IBOutlet var audiChange: UILabel!
}
